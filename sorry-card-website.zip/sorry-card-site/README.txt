YOUR FREE PERSONALIZED SORRY-CARD WEBSITE

Included: index.html (the complete website).

HOW TO TEST:
1. Open index.html in a browser.
2. Enter a recipient name and message, choose a colour, and click Create my card.
3. Copy the generated link and open it in another browser/device to test the recipient view.

HOW TO PUBLISH FOR FREE WITH GITHUB PAGES:
1. Sign in or create a free account at https://github.com
2. Create a new PUBLIC repository named sorry-card (or any name you like).
3. Upload index.html from this folder to the repository's root. README.txt is optional.
4. Open the repository's Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch; select main and /(root), then Save.
6. Wait a minute or two. GitHub will show your public website address, usually https://YOUR-USERNAME.github.io/sorry-card/.
7. Open that address and create a card. The generated card link will use your public website address and can be shared on WhatsApp.

IMPORTANT:
- This is an original, simple apology-card design inspired by the general idea of the example, not a copy of its branding, artwork, or code.
- No paid backend or database is needed. The card details are encoded into the share URL. Anyone with that link can view the message, so don't put private or sensitive information in it.
- GitHub Pages hosting is free for public repositories. A custom domain is optional and may cost money.
